(function(root, factory) {
    if (typeof define === 'function' && define.amd) {
        // AMD.
        define(['expect.js', '../../src/index'], factory);
    } else if (typeof module === 'object' && module.exports) {
        // CommonJS-like environments that support module.exports, like Node.
        factory(require('expect.js'), require('../../src/index'));
    } else {
        // Browser globals (root is window)
        factory(root.expect, root.OaiJeopardy);
    }
}(this, function(expect, OaiJeopardy) {

    'use strict';

    var instance;

    beforeEach(function() {
        instance = new OaiJeopardy.JeopardyQuestionApi();
    });

    var getProperty = function(object, getter, property) {
        // Use getter method if present; otherwise, get the property directly.
        if (typeof object[getter] === 'function'){
            return object[getter]();
        }
        else {
            return object[property];
        }
    }

    var setProperty = function(object, setter, property, value) {
        // Use setter method if present; otherwise, set the property directly.
        if (typeof object[setter] === 'function') {
            object[setter](value);
        }
        else {
            object[property] = value;
        }
    }

    describe('JeopardyQuestionApi', function() { 
        describe('jeopardyQuestionCategories', function() {
            it('should call jeopardyQuestionCategories successfully', function(done) {
                //uncomment below and update the code to test jeopardyQuestionCategories
                //instance.jeopardyQuestionCategories(function(error) {
                    //if (error) throw error;
                    //expect().to.be();
                //});
                done();
            });
        });

        describe('jeopardyQuestionCount', function() {
            it('should call jeopardyQuestionCount successfully', function(done) {
                //uncomment below and update the code to test jeopardyQuestionCount
                //instance.jeopardyQuestionCount(function(error) {
                    //if (error) throw error;
                    //expect().to.be();
                //});
                done();
            });
        });

        describe('jeopardyQuestionCreate', function() {
            it('should call jeopardyQuestionCreate successfully', function(done) {
                //uncomment below and update the code to test jeopardyQuestionCreate
                //instance.jeopardyQuestionCreate(function(error) {
                    //if (error) throw error;
                    //expect().to.be();
                //});
                done();
            });
        });

        describe('jeopardyQuestionCreateChangeStreamGetJeopardyQuestionsChangeStream', function() {
            it('should call jeopardyQuestionCreateChangeStreamGetJeopardyQuestionsChangeStream successfully', function(done) {
                //uncomment below and update the code to test jeopardyQuestionCreateChangeStreamGetJeopardyQuestionsChangeStream
                //instance.jeopardyQuestionCreateChangeStreamGetJeopardyQuestionsChangeStream(function(error) {
                    //if (error) throw error;
                    //expect().to.be();
                //});
                done();
            });
        });

        describe('jeopardyQuestionCreateChangeStreamPostJeopardyQuestionsChangeStream', function() {
            it('should call jeopardyQuestionCreateChangeStreamPostJeopardyQuestionsChangeStream successfully', function(done) {
                //uncomment below and update the code to test jeopardyQuestionCreateChangeStreamPostJeopardyQuestionsChangeStream
                //instance.jeopardyQuestionCreateChangeStreamPostJeopardyQuestionsChangeStream(function(error) {
                    //if (error) throw error;
                    //expect().to.be();
                //});
                done();
            });
        });

        describe('jeopardyQuestionExistsGetJeopardyQuestionsidExists', function() {
            it('should call jeopardyQuestionExistsGetJeopardyQuestionsidExists successfully', function(done) {
                //uncomment below and update the code to test jeopardyQuestionExistsGetJeopardyQuestionsidExists
                //instance.jeopardyQuestionExistsGetJeopardyQuestionsidExists(function(error) {
                    //if (error) throw error;
                    //expect().to.be();
                //});
                done();
            });
        });

        describe('jeopardyQuestionExistsHeadJeopardyQuestionsid', function() {
            it('should call jeopardyQuestionExistsHeadJeopardyQuestionsid successfully', function(done) {
                //uncomment below and update the code to test jeopardyQuestionExistsHeadJeopardyQuestionsid
                //instance.jeopardyQuestionExistsHeadJeopardyQuestionsid(function(error) {
                    //if (error) throw error;
                    //expect().to.be();
                //});
                done();
            });
        });

        describe('jeopardyQuestionFind', function() {
            it('should call jeopardyQuestionFind successfully', function(done) {
                //uncomment below and update the code to test jeopardyQuestionFind
                //instance.jeopardyQuestionFind(function(error) {
                    //if (error) throw error;
                    //expect().to.be();
                //});
                done();
            });
        });

        describe('jeopardyQuestionFindById', function() {
            it('should call jeopardyQuestionFindById successfully', function(done) {
                //uncomment below and update the code to test jeopardyQuestionFindById
                //instance.jeopardyQuestionFindById(function(error) {
                    //if (error) throw error;
                    //expect().to.be();
                //});
                done();
            });
        });

        describe('jeopardyQuestionFindOne', function() {
            it('should call jeopardyQuestionFindOne successfully', function(done) {
                //uncomment below and update the code to test jeopardyQuestionFindOne
                //instance.jeopardyQuestionFindOne(function(error) {
                    //if (error) throw error;
                    //expect().to.be();
                //});
                done();
            });
        });

        describe('jeopardyQuestionPatchOrCreate', function() {
            it('should call jeopardyQuestionPatchOrCreate successfully', function(done) {
                //uncomment below and update the code to test jeopardyQuestionPatchOrCreate
                //instance.jeopardyQuestionPatchOrCreate(function(error) {
                    //if (error) throw error;
                    //expect().to.be();
                //});
                done();
            });
        });

        describe('jeopardyQuestionPrototypePatchAttributes', function() {
            it('should call jeopardyQuestionPrototypePatchAttributes successfully', function(done) {
                //uncomment below and update the code to test jeopardyQuestionPrototypePatchAttributes
                //instance.jeopardyQuestionPrototypePatchAttributes(function(error) {
                    //if (error) throw error;
                    //expect().to.be();
                //});
                done();
            });
        });

        describe('jeopardyQuestionRandom', function() {
            it('should call jeopardyQuestionRandom successfully', function(done) {
                //uncomment below and update the code to test jeopardyQuestionRandom
                //instance.jeopardyQuestionRandom(function(error) {
                    //if (error) throw error;
                    //expect().to.be();
                //});
                done();
            });
        });

        describe('jeopardyQuestionReplaceByIdPostJeopardyQuestionsidReplace', function() {
            it('should call jeopardyQuestionReplaceByIdPostJeopardyQuestionsidReplace successfully', function(done) {
                //uncomment below and update the code to test jeopardyQuestionReplaceByIdPostJeopardyQuestionsidReplace
                //instance.jeopardyQuestionReplaceByIdPostJeopardyQuestionsidReplace(function(error) {
                    //if (error) throw error;
                    //expect().to.be();
                //});
                done();
            });
        });

        describe('jeopardyQuestionReplaceByIdPutJeopardyQuestionsid', function() {
            it('should call jeopardyQuestionReplaceByIdPutJeopardyQuestionsid successfully', function(done) {
                //uncomment below and update the code to test jeopardyQuestionReplaceByIdPutJeopardyQuestionsid
                //instance.jeopardyQuestionReplaceByIdPutJeopardyQuestionsid(function(error) {
                    //if (error) throw error;
                    //expect().to.be();
                //});
                done();
            });
        });

        describe('jeopardyQuestionReplaceOrCreatePostJeopardyQuestionsReplaceOrCreate', function() {
            it('should call jeopardyQuestionReplaceOrCreatePostJeopardyQuestionsReplaceOrCreate successfully', function(done) {
                //uncomment below and update the code to test jeopardyQuestionReplaceOrCreatePostJeopardyQuestionsReplaceOrCreate
                //instance.jeopardyQuestionReplaceOrCreatePostJeopardyQuestionsReplaceOrCreate(function(error) {
                    //if (error) throw error;
                    //expect().to.be();
                //});
                done();
            });
        });

        describe('jeopardyQuestionReplaceOrCreatePutJeopardyQuestions', function() {
            it('should call jeopardyQuestionReplaceOrCreatePutJeopardyQuestions successfully', function(done) {
                //uncomment below and update the code to test jeopardyQuestionReplaceOrCreatePutJeopardyQuestions
                //instance.jeopardyQuestionReplaceOrCreatePutJeopardyQuestions(function(error) {
                    //if (error) throw error;
                    //expect().to.be();
                //});
                done();
            });
        });

        describe('jeopardyQuestionUpdateAll', function() {
            it('should call jeopardyQuestionUpdateAll successfully', function(done) {
                //uncomment below and update the code to test jeopardyQuestionUpdateAll
                //instance.jeopardyQuestionUpdateAll(function(error) {
                    //if (error) throw error;
                    //expect().to.be();
                //});
                done();
            });
        });

        describe('jeopardyQuestionUpsertWithWhere', function() {
            it('should call jeopardyQuestionUpsertWithWhere successfully', function(done) {
                //uncomment below and update the code to test jeopardyQuestionUpsertWithWhere
                //instance.jeopardyQuestionUpsertWithWhere(function(error) {
                    //if (error) throw error;
                    //expect().to.be();
                //});
                done();
            });
        });
    });

}));