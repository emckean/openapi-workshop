(function(root, factory) {
    if (typeof define === 'function' && define.amd) {
        // AMD.
        define(['expect.js', '../../src/index'], factory);
    } else if (typeof module === 'object' && module.exports) {
    // CommonJS-like environments that support module.exports, like Node.
        factory(require('expect.js'), require('../../src/index'));
    } else {
        // Browser globals (root is window)
        factory(root.expect, root.OaiJeopardy);
    }
}(this, function(expect, OaiJeopardy) {
    'use strict';

    var instance;

    beforeEach(function() {
        instance = new OaiJeopardy.JeopardyQuestion();
    });

    var getProperty = function(object, getter, property) {
        // Use getter method if present; otherwise, get the property directly.
        if (typeof object[getter] === 'function'){
            return object[getter]();
        }
        else {
            return object[property];
        }
    }

    var setProperty = function(object, setter, property, value) {
        // Use setter method if present; otherwise, set the property directly.
        if (typeof object[setter] === 'function'){
            object[setter](value);
        }
        else{
            object[property] = value;
        }

    }

    describe('JeopardyQuestion', function() {
        it('should create an instance of JeopardyQuestion', function() {
            // uncomment below and update the code to test JeopardyQuestion
            //var instance = new OaiJeopardy.JeopardyQuestion();
            //expect(instance).to.be.a(OaiJeopardy.JeopardyQuestion);
        });

        it('should have the property question (base name: "question")', function() {
            // uncomment below and update the code to test the property question
            //var instance = new OaiJeopardy.JeopardyQuestion();
            //expect(instance).to.be();
        });

        it('should have the property answer (base name: "answer")', function() {
            // uncomment below and update the code to test the property answer
            //var instance = new OaiJeopardy.JeopardyQuestion();
            //expect(instance).to.be();
        });

        it('should have the property category (base name: "category")', function() {
            // uncomment below and update the code to test the property category
            //var instance = new OaiJeopardy.JeopardyQuestion();
            //expect(instance).to.be();
        });

        it('should have the property id (base name: "id")', function() {
            // uncomment below and update the code to test the property id
            //var instance = new OaiJeopardy.JeopardyQuestion();
            //expect(instance).to.be();
        });

    });

}));