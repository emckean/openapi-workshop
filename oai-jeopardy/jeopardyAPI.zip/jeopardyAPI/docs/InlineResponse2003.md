
[**Back to README**](./README.md)
# InlineResponse2003 <a name="top"></a> 
### Examples
```javascript
    var OaiJeopardy = require('oai_jeopardy');
    var model = new OaiJeopardy.InlineResponse2003()
```
### Fields 
 - [**questions**](#questions)

---


<a name="questions"></a>
#### questions

```javascript
// Type Object
model.questions
```


[**Back to Top**](#top)


