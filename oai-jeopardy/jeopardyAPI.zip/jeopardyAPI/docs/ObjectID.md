
[**Back to README**](./README.md)
# ObjectID <a name="top"></a> 
### Examples
```javascript
    var OaiJeopardy = require('oai_jeopardy');
    var model = new OaiJeopardy.ObjectID()
```
### Fields 

---


[**Back to Top**](#top)


