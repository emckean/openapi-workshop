[**Back to README**](./README.md)

# JeopardyQuestionApi  {#top}

### Methods
 * [**jeopardyQuestionCategories**](#jeopardyQuestionCategories)
 * [**jeopardyQuestionCount**](#jeopardyQuestionCount)
 * [**jeopardyQuestionCreate**](#jeopardyQuestionCreate)
 * [**jeopardyQuestionCreateChangeStreamGetJeopardyQuestionsChangeStream**](#jeopardyQuestionCreateChangeStreamGetJeopardyQuestionsChangeStream)
 * [**jeopardyQuestionCreateChangeStreamPostJeopardyQuestionsChangeStream**](#jeopardyQuestionCreateChangeStreamPostJeopardyQuestionsChangeStream)
 * [**jeopardyQuestionExistsGetJeopardyQuestionsidExists**](#jeopardyQuestionExistsGetJeopardyQuestionsidExists)
 * [**jeopardyQuestionExistsHeadJeopardyQuestionsid**](#jeopardyQuestionExistsHeadJeopardyQuestionsid)
 * [**jeopardyQuestionFind**](#jeopardyQuestionFind)
 * [**jeopardyQuestionFindById**](#jeopardyQuestionFindById)
 * [**jeopardyQuestionFindOne**](#jeopardyQuestionFindOne)
 * [**jeopardyQuestionPatchOrCreate**](#jeopardyQuestionPatchOrCreate)
 * [**jeopardyQuestionPrototypePatchAttributes**](#jeopardyQuestionPrototypePatchAttributes)
 * [**jeopardyQuestionRandom**](#jeopardyQuestionRandom)
 * [**jeopardyQuestionReplaceByIdPostJeopardyQuestionsidReplace**](#jeopardyQuestionReplaceByIdPostJeopardyQuestionsidReplace)
 * [**jeopardyQuestionReplaceByIdPutJeopardyQuestionsid**](#jeopardyQuestionReplaceByIdPutJeopardyQuestionsid)
 * [**jeopardyQuestionReplaceOrCreatePostJeopardyQuestionsReplaceOrCreate**](#jeopardyQuestionReplaceOrCreatePostJeopardyQuestionsReplaceOrCreate)
 * [**jeopardyQuestionReplaceOrCreatePutJeopardyQuestions**](#jeopardyQuestionReplaceOrCreatePutJeopardyQuestions)
 * [**jeopardyQuestionUpdateAll**](#jeopardyQuestionUpdateAll)
 * [**jeopardyQuestionUpsertWithWhere**](#jeopardyQuestionUpsertWithWhere)


### jeopardyQuestionCategories  {#jeopardyQuestionCategories }
---
```javascript
    jeopardyQuestionCategories(callback)
```
>Gets list of categories



- **callback** (required) The callback function, accepting three arguments: error, data, response


#### Response
[**InlineResponse2004**](InlineResponse2004.md)

#### Authentication

No authentication required

### Example
   ```javascript
        var OaiJeopardy = require('oai_jeopardy');
        var apiInstance = new OaiJeopardy.JeopardyQuestionApi();

        var callback = function(error, data, response) {
            if (error) {
                console.error(error);
            } else { 
                console.log('API called successfully. Returned data: ' + data);
            }
        };
        apiInstance.jeopardyQuestionCategories(callback);
   ```

### jeopardyQuestionCount  {#jeopardyQuestionCount }
---
```javascript
    jeopardyQuestionCount(where, opts, callback)
```
>Count instances of the model matched by where from the data source.


- **where**  (optional) Criteria to match model instances
- **opts** (optional) Optional parameters

- **callback** (required) The callback function, accepting three arguments: error, data, response


#### Response
[**InlineResponse2002**](InlineResponse2002.md)

#### Authentication

No authentication required

### Example
   ```javascript
        var OaiJeopardy = require('oai_jeopardy');
        var apiInstance = new OaiJeopardy.JeopardyQuestionApi();
            
        var opts = { 
            'where': "where_example" // String | Criteria to match model instances
        };

        var callback = function(error, data, response) {
            if (error) {
                console.error(error);
            } else { 
                console.log('API called successfully. Returned data: ' + data);
            }
        };
        apiInstance.jeopardyQuestionCount(opts, callback);
   ```

### jeopardyQuestionCreate  {#jeopardyQuestionCreate }
---
```javascript
    jeopardyQuestionCreate(data, opts, callback)
```
>Create a new instance of the model and persist it into the data source.


- **data**  (optional) Model instance data
- **opts** (optional) Optional parameters

- **callback** (required) The callback function, accepting three arguments: error, data, response


#### Response
[**JeopardyQuestion**](JeopardyQuestion.md)

#### Authentication

No authentication required

### Example
   ```javascript
        var OaiJeopardy = require('oai_jeopardy');
        var apiInstance = new OaiJeopardy.JeopardyQuestionApi();
            
        var opts = { 
            'data': new OaiJeopardy.JeopardyQuestion() // JeopardyQuestion | Model instance data
        };

        var callback = function(error, data, response) {
            if (error) {
                console.error(error);
            } else { 
                console.log('API called successfully. Returned data: ' + data);
            }
        };
        apiInstance.jeopardyQuestionCreate(opts, callback);
   ```

### jeopardyQuestionCreateChangeStreamGetJeopardyQuestionsChangeStream  {#jeopardyQuestionCreateChangeStreamGetJeopardyQuestionsChangeStream }
---
```javascript
    jeopardyQuestionCreateChangeStreamGetJeopardyQuestionsChangeStream(options, opts, callback)
```
>Create a change stream.


- **options**  (optional) 
- **opts** (optional) Optional parameters

- **callback** (required) The callback function, accepting three arguments: error, data, response


#### Response
**File**

#### Authentication

No authentication required

### Example
   ```javascript
        var OaiJeopardy = require('oai_jeopardy');
        var apiInstance = new OaiJeopardy.JeopardyQuestionApi();
            
        var opts = { 
            'options': "options_example" // String | 
        };

        var callback = function(error, data, response) {
            if (error) {
                console.error(error);
            } else { 
                console.log('API called successfully. Returned data: ' + data);
            }
        };
        apiInstance.jeopardyQuestionCreateChangeStreamGetJeopardyQuestionsChangeStream(opts, callback);
   ```

### jeopardyQuestionCreateChangeStreamPostJeopardyQuestionsChangeStream  {#jeopardyQuestionCreateChangeStreamPostJeopardyQuestionsChangeStream }
---
```javascript
    jeopardyQuestionCreateChangeStreamPostJeopardyQuestionsChangeStream(options, opts, callback)
```
>Create a change stream.


- **options**  (optional) 
- **opts** (optional) Optional parameters

- **callback** (required) The callback function, accepting three arguments: error, data, response


#### Response
**File**

#### Authentication

No authentication required

### Example
   ```javascript
        var OaiJeopardy = require('oai_jeopardy');
        var apiInstance = new OaiJeopardy.JeopardyQuestionApi();
            
        var opts = { 
            'options': "options_example" // String | 
        };

        var callback = function(error, data, response) {
            if (error) {
                console.error(error);
            } else { 
                console.log('API called successfully. Returned data: ' + data);
            }
        };
        apiInstance.jeopardyQuestionCreateChangeStreamPostJeopardyQuestionsChangeStream(opts, callback);
   ```

### jeopardyQuestionExistsGetJeopardyQuestionsidExists  {#jeopardyQuestionExistsGetJeopardyQuestionsidExists }
---
```javascript
    jeopardyQuestionExistsGetJeopardyQuestionsidExists(id, callback)
```
>Check whether a model instance exists in the data source.


- **id**  (required) Model id

- **callback** (required) The callback function, accepting three arguments: error, data, response


#### Response
[**InlineResponse200**](InlineResponse200.md)

#### Authentication

No authentication required

### Example
   ```javascript
        var OaiJeopardy = require('oai_jeopardy');
        var apiInstance = new OaiJeopardy.JeopardyQuestionApi();
            
        var id = "id_example"; // String | Model id
            

        var callback = function(error, data, response) {
            if (error) {
                console.error(error);
            } else { 
                console.log('API called successfully. Returned data: ' + data);
            }
        };
        apiInstance.jeopardyQuestionExistsGetJeopardyQuestionsidExists(id, callback);
   ```

### jeopardyQuestionExistsHeadJeopardyQuestionsid  {#jeopardyQuestionExistsHeadJeopardyQuestionsid }
---
```javascript
    jeopardyQuestionExistsHeadJeopardyQuestionsid(id, callback)
```
>Check whether a model instance exists in the data source.


- **id**  (required) Model id

- **callback** (required) The callback function, accepting three arguments: error, data, response


#### Response
[**InlineResponse200**](InlineResponse200.md)

#### Authentication

No authentication required

### Example
   ```javascript
        var OaiJeopardy = require('oai_jeopardy');
        var apiInstance = new OaiJeopardy.JeopardyQuestionApi();
            
        var id = "id_example"; // String | Model id
            

        var callback = function(error, data, response) {
            if (error) {
                console.error(error);
            } else { 
                console.log('API called successfully. Returned data: ' + data);
            }
        };
        apiInstance.jeopardyQuestionExistsHeadJeopardyQuestionsid(id, callback);
   ```

### jeopardyQuestionFind  {#jeopardyQuestionFind }
---
```javascript
    jeopardyQuestionFind(filter, opts, callback)
```
>Find all instances of the model matched by filter from the data source.


- **filter**  (optional) Filter defining fields, where, include, order, offset, and limit - must be a JSON-encoded string ({\&quot;something\&quot;:\&quot;value\&quot;})
- **opts** (optional) Optional parameters

- **callback** (required) The callback function, accepting three arguments: error, data, response


#### Response
[**[JeopardyQuestion]**](JeopardyQuestion.md)

#### Authentication

No authentication required

### Example
   ```javascript
        var OaiJeopardy = require('oai_jeopardy');
        var apiInstance = new OaiJeopardy.JeopardyQuestionApi();
            
        var opts = { 
            'filter': "filter_example" // String | Filter defining fields, where, include, order, offset, and limit - must be a JSON-encoded string ({\"something\":\"value\"})
        };

        var callback = function(error, data, response) {
            if (error) {
                console.error(error);
            } else { 
                console.log('API called successfully. Returned data: ' + data);
            }
        };
        apiInstance.jeopardyQuestionFind(opts, callback);
   ```

### jeopardyQuestionFindById  {#jeopardyQuestionFindById }
---
```javascript
    jeopardyQuestionFindById(id, filter, opts, callback)
```
>Find a model instance by {{id}} from the data source.


- **id**  (required) Model id
- **filter**  (optional) Filter defining fields and include - must be a JSON-encoded string ({\&quot;something\&quot;:\&quot;value\&quot;})
- **opts** (optional) Optional parameters

- **callback** (required) The callback function, accepting three arguments: error, data, response


#### Response
[**JeopardyQuestion**](JeopardyQuestion.md)

#### Authentication

No authentication required

### Example
   ```javascript
        var OaiJeopardy = require('oai_jeopardy');
        var apiInstance = new OaiJeopardy.JeopardyQuestionApi();
            
        var id = "id_example"; // String | Model id
            
        var opts = { 
            'filter': "filter_example" // String | Filter defining fields and include - must be a JSON-encoded string ({\"something\":\"value\"})
        };

        var callback = function(error, data, response) {
            if (error) {
                console.error(error);
            } else { 
                console.log('API called successfully. Returned data: ' + data);
            }
        };
        apiInstance.jeopardyQuestionFindById(id, opts, callback);
   ```

### jeopardyQuestionFindOne  {#jeopardyQuestionFindOne }
---
```javascript
    jeopardyQuestionFindOne(filter, opts, callback)
```
>Find first instance of the model matched by filter from the data source.


- **filter**  (optional) Filter defining fields, where, include, order, offset, and limit - must be a JSON-encoded string ({\&quot;something\&quot;:\&quot;value\&quot;})
- **opts** (optional) Optional parameters

- **callback** (required) The callback function, accepting three arguments: error, data, response


#### Response
[**JeopardyQuestion**](JeopardyQuestion.md)

#### Authentication

No authentication required

### Example
   ```javascript
        var OaiJeopardy = require('oai_jeopardy');
        var apiInstance = new OaiJeopardy.JeopardyQuestionApi();
            
        var opts = { 
            'filter': "filter_example" // String | Filter defining fields, where, include, order, offset, and limit - must be a JSON-encoded string ({\"something\":\"value\"})
        };

        var callback = function(error, data, response) {
            if (error) {
                console.error(error);
            } else { 
                console.log('API called successfully. Returned data: ' + data);
            }
        };
        apiInstance.jeopardyQuestionFindOne(opts, callback);
   ```

### jeopardyQuestionPatchOrCreate  {#jeopardyQuestionPatchOrCreate }
---
```javascript
    jeopardyQuestionPatchOrCreate(data, opts, callback)
```
>Patch an existing model instance or insert a new one into the data source.


- **data**  (optional) Model instance data
- **opts** (optional) Optional parameters

- **callback** (required) The callback function, accepting three arguments: error, data, response


#### Response
[**JeopardyQuestion**](JeopardyQuestion.md)

#### Authentication

No authentication required

### Example
   ```javascript
        var OaiJeopardy = require('oai_jeopardy');
        var apiInstance = new OaiJeopardy.JeopardyQuestionApi();
            
        var opts = { 
            'data': new OaiJeopardy.JeopardyQuestion() // JeopardyQuestion | Model instance data
        };

        var callback = function(error, data, response) {
            if (error) {
                console.error(error);
            } else { 
                console.log('API called successfully. Returned data: ' + data);
            }
        };
        apiInstance.jeopardyQuestionPatchOrCreate(opts, callback);
   ```

### jeopardyQuestionPrototypePatchAttributes  {#jeopardyQuestionPrototypePatchAttributes }
---
```javascript
    jeopardyQuestionPrototypePatchAttributes(id, data, opts, callback)
```
>Patch attributes for a model instance and persist it into the data source.


- **id**  (required) jeopardyQuestion id
- **data**  (optional) An object of model property name/value pairs
- **opts** (optional) Optional parameters

- **callback** (required) The callback function, accepting three arguments: error, data, response


#### Response
[**JeopardyQuestion**](JeopardyQuestion.md)

#### Authentication

No authentication required

### Example
   ```javascript
        var OaiJeopardy = require('oai_jeopardy');
        var apiInstance = new OaiJeopardy.JeopardyQuestionApi();
            
        var id = "id_example"; // String | jeopardyQuestion id
            
        var opts = { 
            'data': new OaiJeopardy.JeopardyQuestion() // JeopardyQuestion | An object of model property name/value pairs
        };

        var callback = function(error, data, response) {
            if (error) {
                console.error(error);
            } else { 
                console.log('API called successfully. Returned data: ' + data);
            }
        };
        apiInstance.jeopardyQuestionPrototypePatchAttributes(id, opts, callback);
   ```

### jeopardyQuestionRandom  {#jeopardyQuestionRandom }
---
```javascript
    jeopardyQuestionRandom(callback)
```
>Gets one random question



- **callback** (required) The callback function, accepting three arguments: error, data, response


#### Response
[**InlineResponse2003**](InlineResponse2003.md)

#### Authentication

No authentication required

### Example
   ```javascript
        var OaiJeopardy = require('oai_jeopardy');
        var apiInstance = new OaiJeopardy.JeopardyQuestionApi();

        var callback = function(error, data, response) {
            if (error) {
                console.error(error);
            } else { 
                console.log('API called successfully. Returned data: ' + data);
            }
        };
        apiInstance.jeopardyQuestionRandom(callback);
   ```

### jeopardyQuestionReplaceByIdPostJeopardyQuestionsidReplace  {#jeopardyQuestionReplaceByIdPostJeopardyQuestionsidReplace }
---
```javascript
    jeopardyQuestionReplaceByIdPostJeopardyQuestionsidReplace(id, data, opts, callback)
```
>Replace attributes for a model instance and persist it into the data source.


- **id**  (required) Model id
- **data**  (optional) Model instance data
- **opts** (optional) Optional parameters

- **callback** (required) The callback function, accepting three arguments: error, data, response


#### Response
[**JeopardyQuestion**](JeopardyQuestion.md)

#### Authentication

No authentication required

### Example
   ```javascript
        var OaiJeopardy = require('oai_jeopardy');
        var apiInstance = new OaiJeopardy.JeopardyQuestionApi();
            
        var id = "id_example"; // String | Model id
            
        var opts = { 
            'data': new OaiJeopardy.JeopardyQuestion() // JeopardyQuestion | Model instance data
        };

        var callback = function(error, data, response) {
            if (error) {
                console.error(error);
            } else { 
                console.log('API called successfully. Returned data: ' + data);
            }
        };
        apiInstance.jeopardyQuestionReplaceByIdPostJeopardyQuestionsidReplace(id, opts, callback);
   ```

### jeopardyQuestionReplaceByIdPutJeopardyQuestionsid  {#jeopardyQuestionReplaceByIdPutJeopardyQuestionsid }
---
```javascript
    jeopardyQuestionReplaceByIdPutJeopardyQuestionsid(id, data, opts, callback)
```
>Replace attributes for a model instance and persist it into the data source.


- **id**  (required) Model id
- **data**  (optional) Model instance data
- **opts** (optional) Optional parameters

- **callback** (required) The callback function, accepting three arguments: error, data, response


#### Response
[**JeopardyQuestion**](JeopardyQuestion.md)

#### Authentication

No authentication required

### Example
   ```javascript
        var OaiJeopardy = require('oai_jeopardy');
        var apiInstance = new OaiJeopardy.JeopardyQuestionApi();
            
        var id = "id_example"; // String | Model id
            
        var opts = { 
            'data': new OaiJeopardy.JeopardyQuestion() // JeopardyQuestion | Model instance data
        };

        var callback = function(error, data, response) {
            if (error) {
                console.error(error);
            } else { 
                console.log('API called successfully. Returned data: ' + data);
            }
        };
        apiInstance.jeopardyQuestionReplaceByIdPutJeopardyQuestionsid(id, opts, callback);
   ```

### jeopardyQuestionReplaceOrCreatePostJeopardyQuestionsReplaceOrCreate  {#jeopardyQuestionReplaceOrCreatePostJeopardyQuestionsReplaceOrCreate }
---
```javascript
    jeopardyQuestionReplaceOrCreatePostJeopardyQuestionsReplaceOrCreate(data, opts, callback)
```
>Replace an existing model instance or insert a new one into the data source.


- **data**  (optional) Model instance data
- **opts** (optional) Optional parameters

- **callback** (required) The callback function, accepting three arguments: error, data, response


#### Response
[**JeopardyQuestion**](JeopardyQuestion.md)

#### Authentication

No authentication required

### Example
   ```javascript
        var OaiJeopardy = require('oai_jeopardy');
        var apiInstance = new OaiJeopardy.JeopardyQuestionApi();
            
        var opts = { 
            'data': new OaiJeopardy.JeopardyQuestion() // JeopardyQuestion | Model instance data
        };

        var callback = function(error, data, response) {
            if (error) {
                console.error(error);
            } else { 
                console.log('API called successfully. Returned data: ' + data);
            }
        };
        apiInstance.jeopardyQuestionReplaceOrCreatePostJeopardyQuestionsReplaceOrCreate(opts, callback);
   ```

### jeopardyQuestionReplaceOrCreatePutJeopardyQuestions  {#jeopardyQuestionReplaceOrCreatePutJeopardyQuestions }
---
```javascript
    jeopardyQuestionReplaceOrCreatePutJeopardyQuestions(data, opts, callback)
```
>Replace an existing model instance or insert a new one into the data source.


- **data**  (optional) Model instance data
- **opts** (optional) Optional parameters

- **callback** (required) The callback function, accepting three arguments: error, data, response


#### Response
[**JeopardyQuestion**](JeopardyQuestion.md)

#### Authentication

No authentication required

### Example
   ```javascript
        var OaiJeopardy = require('oai_jeopardy');
        var apiInstance = new OaiJeopardy.JeopardyQuestionApi();
            
        var opts = { 
            'data': new OaiJeopardy.JeopardyQuestion() // JeopardyQuestion | Model instance data
        };

        var callback = function(error, data, response) {
            if (error) {
                console.error(error);
            } else { 
                console.log('API called successfully. Returned data: ' + data);
            }
        };
        apiInstance.jeopardyQuestionReplaceOrCreatePutJeopardyQuestions(opts, callback);
   ```

### jeopardyQuestionUpdateAll  {#jeopardyQuestionUpdateAll }
---
```javascript
    jeopardyQuestionUpdateAll(where, data, opts, callback)
```
>Update instances of the model matched by {{where}} from the data source.


- **where**  (optional) Criteria to match model instances
- **data**  (optional) An object of model property name/value pairs
- **opts** (optional) Optional parameters

- **callback** (required) The callback function, accepting three arguments: error, data, response


#### Response
[**InlineResponse2001**](InlineResponse2001.md)

#### Authentication

No authentication required

### Example
   ```javascript
        var OaiJeopardy = require('oai_jeopardy');
        var apiInstance = new OaiJeopardy.JeopardyQuestionApi();
            
        var opts = { 
            'where': "where_example", // String | Criteria to match model instances
            'data': new OaiJeopardy.JeopardyQuestion() // JeopardyQuestion | An object of model property name/value pairs
        };

        var callback = function(error, data, response) {
            if (error) {
                console.error(error);
            } else { 
                console.log('API called successfully. Returned data: ' + data);
            }
        };
        apiInstance.jeopardyQuestionUpdateAll(opts, callback);
   ```

### jeopardyQuestionUpsertWithWhere  {#jeopardyQuestionUpsertWithWhere }
---
```javascript
    jeopardyQuestionUpsertWithWhere(where, data, opts, callback)
```
>Update an existing model instance or insert a new one into the data source based on the where criteria.


- **where**  (optional) Criteria to match model instances
- **data**  (optional) An object of model property name/value pairs
- **opts** (optional) Optional parameters

- **callback** (required) The callback function, accepting three arguments: error, data, response


#### Response
[**JeopardyQuestion**](JeopardyQuestion.md)

#### Authentication

No authentication required

### Example
   ```javascript
        var OaiJeopardy = require('oai_jeopardy');
        var apiInstance = new OaiJeopardy.JeopardyQuestionApi();
            
        var opts = { 
            'where': "where_example", // String | Criteria to match model instances
            'data': new OaiJeopardy.JeopardyQuestion() // JeopardyQuestion | An object of model property name/value pairs
        };

        var callback = function(error, data, response) {
            if (error) {
                console.error(error);
            } else { 
                console.log('API called successfully. Returned data: ' + data);
            }
        };
        apiInstance.jeopardyQuestionUpsertWithWhere(opts, callback);
   ```

[**Back to Top**](#top)
