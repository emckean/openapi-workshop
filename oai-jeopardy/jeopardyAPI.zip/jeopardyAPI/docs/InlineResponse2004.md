
[**Back to README**](./README.md)
# InlineResponse2004 <a name="top"></a> 
### Examples
```javascript
    var OaiJeopardy = require('oai_jeopardy');
    var model = new OaiJeopardy.InlineResponse2004()
```
### Fields 
 - [**categories**](#categories)

---


<a name="categories"></a>
#### categories

```javascript
// Type Object
model.categories
```


[**Back to Top**](#top)


