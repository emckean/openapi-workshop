
[**Back to README**](./README.md)
# JeopardyQuestion <a name="top"></a> 
### Examples
```javascript
    var OaiJeopardy = require('oai_jeopardy');
    var model = new OaiJeopardy.JeopardyQuestion()
```
### Fields 
 - [**question**](#question)
 - [**answer**](#answer)
 - [**category**](#category)
 - [**id**](#id)

---


<a name="question"></a>
#### question

```javascript
// Type String
model.question
```


<a name="answer"></a>
#### answer

```javascript
// Type String
model.answer
```


<a name="category"></a>
#### category

```javascript
// Type String
model.category
```


<a name="id"></a>
#### id

```javascript
// Type ObjectID
model.id
```


[**Back to Top**](#top)


