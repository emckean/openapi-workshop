
[**Back to README**](./README.md)
# InlineResponse2002 <a name="top"></a> 
### Examples
```javascript
    var OaiJeopardy = require('oai_jeopardy');
    var model = new OaiJeopardy.InlineResponse2002()
```
### Fields 
 - [**count**](#count)

---


<a name="count"></a>
#### count

```javascript
// Type Number
model.count
```


[**Back to Top**](#top)


