
[**Back to README**](./README.md)
# InlineResponse2001 <a name="top"></a> 

### Summary
Information related to the outcome of the operation

### Examples
```javascript
    var OaiJeopardy = require('oai_jeopardy');
    var model = new OaiJeopardy.InlineResponse2001()
```
### Fields 
 - [**count**](#count)

---


<a name="count"></a>
#### count

```javascript
// Type Number
model.count
```

- The number of instances updated

[**Back to Top**](#top)


