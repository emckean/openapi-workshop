
[**Back to README**](./README.md)
# InlineResponse200 <a name="top"></a> 
### Examples
```javascript
    var OaiJeopardy = require('oai_jeopardy');
    var model = new OaiJeopardy.InlineResponse200()
```
### Fields 
 - [**exists**](#exists)

---


<a name="exists"></a>
#### exists

```javascript
// Type Boolean
model.exists
```


[**Back to Top**](#top)


