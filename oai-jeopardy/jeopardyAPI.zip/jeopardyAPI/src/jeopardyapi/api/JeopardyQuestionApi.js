(function(root, factory) {
    if (typeof define === 'function' && define.amd) {
        // AMD. Register as an anonymous module.
        define(['jeopardyapi/ApiClient', 'jeopardyapi/jeopardyapi.model/InlineResponse200', 'jeopardyapi/jeopardyapi.model/InlineResponse2001', 'jeopardyapi/jeopardyapi.model/InlineResponse2002', 'jeopardyapi/jeopardyapi.model/InlineResponse2003', 'jeopardyapi/jeopardyapi.model/InlineResponse2004', 'jeopardyapi/jeopardyapi.model/JeopardyQuestion'], factory);
    } else if (typeof module === 'object' && module.exports) {
        // CommonJS-like environments that support module.exports, like Node.
        module.exports = factory(require('../ApiClient'), require('../jeopardyapi.model/InlineResponse200'), require('../jeopardyapi.model/InlineResponse2001'), require('../jeopardyapi.model/InlineResponse2002'), require('../jeopardyapi.model/InlineResponse2003'), require('../jeopardyapi.model/InlineResponse2004'), require('../jeopardyapi.model/JeopardyQuestion'));
    } else {
        // Browser globals (root is window)
        if (!root.OaiJeopardy) {
            root.OaiJeopardy = {};
        }
        root.OaiJeopardy.JeopardyQuestionApi = factory(root.OaiJeopardy.ApiClient, root.OaiJeopardy.InlineResponse200, root.OaiJeopardy.InlineResponse2001, root.OaiJeopardy.InlineResponse2002, root.OaiJeopardy.InlineResponse2003, root.OaiJeopardy.InlineResponse2004, root.OaiJeopardy.JeopardyQuestion);
    }
}(this, function(ApiClient, InlineResponse200, InlineResponse2001, InlineResponse2002, InlineResponse2003, InlineResponse2004, JeopardyQuestion) {
    'use strict';

    /**
        * JeopardyQuestion service.
        * @module jeopardyapi/api/JeopardyQuestionApi
        * @version 1.0.0
    */

    /**
        * Constructs a new JeopardyQuestionApi.
        * 
        * @alias {module: jeopardyapi/api/JeopardyQuestionApi }
        * @class
        * @param {module: jeopardyapi/ApiClient} apiClient Optional API client implementation to use,
        * default to {@link module:{#invokerPackage}}/ApiClient#instance} if unspecified.
    */

    var exports = function(apiClient) {
        this.apiClient = apiClient || ApiClient.instance;

            
            /**
                * Callback function to receive the result of the jeopardyQuestionCategories operation.
                * @callback module: jeopardyapi/api/JeopardyQuestionApi~jeopardyQuestionCategoriesCallback
                * @param {String} error Error message, if any.
                * @param  data The data returned by the service call.
                * @param {String} response The complete HTTP response.
            */
            /**
                * Gets list of categories
                * @param {module:jeopardyapi/api/JeopardyQuestionApi~jeopardyQuestionCategoriesCallback} callback The callback function, accepting three arguments: error, data, response
                * data is of type: {@link <&vendorExtensions.x-jsdoc-type>}
            */

            this.jeopardyQuestionCategories = function(callback){ 
                var postBody = null;



                var contentTypes = ['application/json', 'application/x-www-form-urlencoded', 'application/xml', 'text/xml'];
                var accepts = ['application/json', 'application/xml', 'text/xml', 'application/javascript', 'text/javascript'];
                var returnType = InlineResponse2004

                return this.apiClient.callApi('/jeopardyQuestions/categories', 'GET', {}, {}, {}, {}, postBody, [], contentTypes, accepts, returnType, callback);
            };
                        
            /**
                * Callback function to receive the result of the jeopardyQuestionCount operation.
                * @callback module: jeopardyapi/api/JeopardyQuestionApi~jeopardyQuestionCountCallback
                * @param {String} error Error message, if any.
                * @param  data The data returned by the service call.
                * @param {String} response The complete HTTP response.
            */
            /**
                * Count instances of the model matched by where from the data source.
                * @param {Object} opts Optional parameters
                * @param String opts.where Criteria to match model instances
                * @param {module:jeopardyapi/api/JeopardyQuestionApi~jeopardyQuestionCountCallback} callback The callback function, accepting three arguments: error, data, response
                * data is of type: {@link <&vendorExtensions.x-jsdoc-type>}
            */

            this.jeopardyQuestionCount = function(opts, callback){ 
                var opts = opts || {};
                var postBody = null;


                var queryParams = {
                    'where': opts['where']
                };

                var contentTypes = ['application/json', 'application/x-www-form-urlencoded', 'application/xml', 'text/xml'];
                var accepts = ['application/json', 'application/xml', 'text/xml', 'application/javascript', 'text/javascript'];
                var returnType = InlineResponse2002

                return this.apiClient.callApi('/jeopardyQuestions/count', 'GET', {}, queryParams, {}, {}, postBody, [], contentTypes, accepts, returnType, callback);
            };
                        
            /**
                * Callback function to receive the result of the jeopardyQuestionCreate operation.
                * @callback module: jeopardyapi/api/JeopardyQuestionApi~jeopardyQuestionCreateCallback
                * @param {String} error Error message, if any.
                * @param  data The data returned by the service call.
                * @param {String} response The complete HTTP response.
            */
            /**
                * Create a new instance of the model and persist it into the data source.
                * @param {Object} opts Optional parameters
                * @param module:jeopardyapi/jeopardyapi.model/JeopardyQuestion opts.data Model instance data
                * @param {module:jeopardyapi/api/JeopardyQuestionApi~jeopardyQuestionCreateCallback} callback The callback function, accepting three arguments: error, data, response
                * data is of type: {@link <&vendorExtensions.x-jsdoc-type>}
            */

            this.jeopardyQuestionCreate = function(opts, callback){ 
                var opts = opts || {};
                var postBody = opts['data'];



                var contentTypes = ['application/json', 'application/x-www-form-urlencoded', 'application/xml', 'text/xml'];
                var accepts = ['application/json', 'application/xml', 'text/xml', 'application/javascript', 'text/javascript'];
                var returnType = JeopardyQuestion

                return this.apiClient.callApi('/jeopardyQuestions', 'POST', {}, {}, {}, {}, postBody, [], contentTypes, accepts, returnType, callback);
            };
                        
            /**
                * Callback function to receive the result of the jeopardyQuestionCreateChangeStreamGetJeopardyQuestionsChangeStream operation.
                * @callback module: jeopardyapi/api/JeopardyQuestionApi~jeopardyQuestionCreateChangeStreamGetJeopardyQuestionsChangeStreamCallback
                * @param {String} error Error message, if any.
                * @param  data The data returned by the service call.
                * @param {String} response The complete HTTP response.
            */
            /**
                * Create a change stream.
                * @param {Object} opts Optional parameters
                * @param String opts.options 
                * @param {module:jeopardyapi/api/JeopardyQuestionApi~jeopardyQuestionCreateChangeStreamGetJeopardyQuestionsChangeStreamCallback} callback The callback function, accepting three arguments: error, data, response
                * data is of type: {@link <&vendorExtensions.x-jsdoc-type>}
            */

            this.jeopardyQuestionCreateChangeStreamGetJeopardyQuestionsChangeStream = function(opts, callback){ 
                var opts = opts || {};
                var postBody = null;


                var queryParams = {
                    'options': opts['options']
                };

                var contentTypes = ['application/json', 'application/x-www-form-urlencoded', 'application/xml', 'text/xml'];
                var accepts = ['application/json', 'application/xml', 'text/xml', 'application/javascript', 'text/javascript'];
                var returnType = File

                return this.apiClient.callApi('/jeopardyQuestions/change-stream', 'GET', {}, queryParams, {}, {}, postBody, [], contentTypes, accepts, returnType, callback);
            };
                        
            /**
                * Callback function to receive the result of the jeopardyQuestionCreateChangeStreamPostJeopardyQuestionsChangeStream operation.
                * @callback module: jeopardyapi/api/JeopardyQuestionApi~jeopardyQuestionCreateChangeStreamPostJeopardyQuestionsChangeStreamCallback
                * @param {String} error Error message, if any.
                * @param  data The data returned by the service call.
                * @param {String} response The complete HTTP response.
            */
            /**
                * Create a change stream.
                * @param {Object} opts Optional parameters
                * @param String opts.options 
                * @param {module:jeopardyapi/api/JeopardyQuestionApi~jeopardyQuestionCreateChangeStreamPostJeopardyQuestionsChangeStreamCallback} callback The callback function, accepting three arguments: error, data, response
                * data is of type: {@link <&vendorExtensions.x-jsdoc-type>}
            */

            this.jeopardyQuestionCreateChangeStreamPostJeopardyQuestionsChangeStream = function(opts, callback){ 
                var opts = opts || {};
                var postBody = null;


                var formParams = {
                    'options': opts['options']
                };
                
                var contentTypes = ['application/json', 'application/x-www-form-urlencoded', 'application/xml', 'text/xml'];
                var accepts = ['application/json', 'application/xml', 'text/xml', 'application/javascript', 'text/javascript'];
                var returnType = File

                return this.apiClient.callApi('/jeopardyQuestions/change-stream', 'POST', {}, {}, {}, formParams, postBody, [], contentTypes, accepts, returnType, callback);
            };
                        
            /**
                * Callback function to receive the result of the jeopardyQuestionExistsGetJeopardyQuestionsidExists operation.
                * @callback module: jeopardyapi/api/JeopardyQuestionApi~jeopardyQuestionExistsGetJeopardyQuestionsidExistsCallback
                * @param {String} error Error message, if any.
                * @param  data The data returned by the service call.
                * @param {String} response The complete HTTP response.
            */
            /**
                * Check whether a model instance exists in the data source.
                * @param String id Model id
                * @param {module:jeopardyapi/api/JeopardyQuestionApi~jeopardyQuestionExistsGetJeopardyQuestionsidExistsCallback} callback The callback function, accepting three arguments: error, data, response
                * data is of type: {@link <&vendorExtensions.x-jsdoc-type>}
            */

            this.jeopardyQuestionExistsGetJeopardyQuestionsidExists = function(id, callback){ 
                var postBody = null;
                // verify the required parameter 'id' is set
                if (id === undefined || id === null) {
                    throw new Error("Missing the required parameter 'id' when calling jeopardyQuestionExistsGetJeopardyQuestionsidExists");
                }
            

                var pathParams = {
                    'id': id
                };

                var contentTypes = ['application/json', 'application/x-www-form-urlencoded', 'application/xml', 'text/xml'];
                var accepts = ['application/json', 'application/xml', 'text/xml', 'application/javascript', 'text/javascript'];
                var returnType = InlineResponse200

                return this.apiClient.callApi('/jeopardyQuestions/{id}/exists', 'GET', pathParams, {}, {}, {}, postBody, [], contentTypes, accepts, returnType, callback);
            };
                        
            /**
                * Callback function to receive the result of the jeopardyQuestionExistsHeadJeopardyQuestionsid operation.
                * @callback module: jeopardyapi/api/JeopardyQuestionApi~jeopardyQuestionExistsHeadJeopardyQuestionsidCallback
                * @param {String} error Error message, if any.
                * @param  data The data returned by the service call.
                * @param {String} response The complete HTTP response.
            */
            /**
                * Check whether a model instance exists in the data source.
                * @param String id Model id
                * @param {module:jeopardyapi/api/JeopardyQuestionApi~jeopardyQuestionExistsHeadJeopardyQuestionsidCallback} callback The callback function, accepting three arguments: error, data, response
                * data is of type: {@link <&vendorExtensions.x-jsdoc-type>}
            */

            this.jeopardyQuestionExistsHeadJeopardyQuestionsid = function(id, callback){ 
                var postBody = null;
                // verify the required parameter 'id' is set
                if (id === undefined || id === null) {
                    throw new Error("Missing the required parameter 'id' when calling jeopardyQuestionExistsHeadJeopardyQuestionsid");
                }
            

                var pathParams = {
                    'id': id
                };

                var contentTypes = ['application/json', 'application/x-www-form-urlencoded', 'application/xml', 'text/xml'];
                var accepts = ['application/json', 'application/xml', 'text/xml', 'application/javascript', 'text/javascript'];
                var returnType = InlineResponse200

                return this.apiClient.callApi('/jeopardyQuestions/{id}', 'HEAD', pathParams, {}, {}, {}, postBody, [], contentTypes, accepts, returnType, callback);
            };
                        
            /**
                * Callback function to receive the result of the jeopardyQuestionFind operation.
                * @callback module: jeopardyapi/api/JeopardyQuestionApi~jeopardyQuestionFindCallback
                * @param {String} error Error message, if any.
                * @param  data The data returned by the service call.
                * @param {String} response The complete HTTP response.
            */
            /**
                * Find all instances of the model matched by filter from the data source.
                * @param {Object} opts Optional parameters
                * @param String opts.filter Filter defining fields, where, include, order, offset, and limit - must be a JSON-encoded string ({\&quot;something\&quot;:\&quot;value\&quot;})
                * @param {module:jeopardyapi/api/JeopardyQuestionApi~jeopardyQuestionFindCallback} callback The callback function, accepting three arguments: error, data, response
                * data is of type: {@link <&vendorExtensions.x-jsdoc-type>}
            */

            this.jeopardyQuestionFind = function(opts, callback){ 
                var opts = opts || {};
                var postBody = null;


                var queryParams = {
                    'filter': opts['filter']
                };

                var contentTypes = ['application/json', 'application/x-www-form-urlencoded', 'application/xml', 'text/xml'];
                var accepts = ['application/json', 'application/xml', 'text/xml', 'application/javascript', 'text/javascript'];
                var returnType = [JeopardyQuestion]

                return this.apiClient.callApi('/jeopardyQuestions', 'GET', {}, queryParams, {}, {}, postBody, [], contentTypes, accepts, returnType, callback);
            };
                        
            /**
                * Callback function to receive the result of the jeopardyQuestionFindById operation.
                * @callback module: jeopardyapi/api/JeopardyQuestionApi~jeopardyQuestionFindByIdCallback
                * @param {String} error Error message, if any.
                * @param  data The data returned by the service call.
                * @param {String} response The complete HTTP response.
            */
            /**
                * Find a model instance by {{id}} from the data source.
                * @param String id Model id
                * @param {Object} opts Optional parameters
                * @param String opts.filter Filter defining fields and include - must be a JSON-encoded string ({\&quot;something\&quot;:\&quot;value\&quot;})
                * @param {module:jeopardyapi/api/JeopardyQuestionApi~jeopardyQuestionFindByIdCallback} callback The callback function, accepting three arguments: error, data, response
                * data is of type: {@link <&vendorExtensions.x-jsdoc-type>}
            */

            this.jeopardyQuestionFindById = function(id, opts, callback){ 
                var opts = opts || {};
                var postBody = null;
                // verify the required parameter 'id' is set
                if (id === undefined || id === null) {
                    throw new Error("Missing the required parameter 'id' when calling jeopardyQuestionFindById");
                }
            

                var pathParams = {
                    'id': id
                };
                var queryParams = {
                    'filter': opts['filter']
                };

                var contentTypes = ['application/json', 'application/x-www-form-urlencoded', 'application/xml', 'text/xml'];
                var accepts = ['application/json', 'application/xml', 'text/xml', 'application/javascript', 'text/javascript'];
                var returnType = JeopardyQuestion

                return this.apiClient.callApi('/jeopardyQuestions/{id}', 'GET', pathParams, queryParams, {}, {}, postBody, [], contentTypes, accepts, returnType, callback);
            };
                        
            /**
                * Callback function to receive the result of the jeopardyQuestionFindOne operation.
                * @callback module: jeopardyapi/api/JeopardyQuestionApi~jeopardyQuestionFindOneCallback
                * @param {String} error Error message, if any.
                * @param  data The data returned by the service call.
                * @param {String} response The complete HTTP response.
            */
            /**
                * Find first instance of the model matched by filter from the data source.
                * @param {Object} opts Optional parameters
                * @param String opts.filter Filter defining fields, where, include, order, offset, and limit - must be a JSON-encoded string ({\&quot;something\&quot;:\&quot;value\&quot;})
                * @param {module:jeopardyapi/api/JeopardyQuestionApi~jeopardyQuestionFindOneCallback} callback The callback function, accepting three arguments: error, data, response
                * data is of type: {@link <&vendorExtensions.x-jsdoc-type>}
            */

            this.jeopardyQuestionFindOne = function(opts, callback){ 
                var opts = opts || {};
                var postBody = null;


                var queryParams = {
                    'filter': opts['filter']
                };

                var contentTypes = ['application/json', 'application/x-www-form-urlencoded', 'application/xml', 'text/xml'];
                var accepts = ['application/json', 'application/xml', 'text/xml', 'application/javascript', 'text/javascript'];
                var returnType = JeopardyQuestion

                return this.apiClient.callApi('/jeopardyQuestions/findOne', 'GET', {}, queryParams, {}, {}, postBody, [], contentTypes, accepts, returnType, callback);
            };
                        
            /**
                * Callback function to receive the result of the jeopardyQuestionPatchOrCreate operation.
                * @callback module: jeopardyapi/api/JeopardyQuestionApi~jeopardyQuestionPatchOrCreateCallback
                * @param {String} error Error message, if any.
                * @param  data The data returned by the service call.
                * @param {String} response The complete HTTP response.
            */
            /**
                * Patch an existing model instance or insert a new one into the data source.
                * @param {Object} opts Optional parameters
                * @param module:jeopardyapi/jeopardyapi.model/JeopardyQuestion opts.data Model instance data
                * @param {module:jeopardyapi/api/JeopardyQuestionApi~jeopardyQuestionPatchOrCreateCallback} callback The callback function, accepting three arguments: error, data, response
                * data is of type: {@link <&vendorExtensions.x-jsdoc-type>}
            */

            this.jeopardyQuestionPatchOrCreate = function(opts, callback){ 
                var opts = opts || {};
                var postBody = opts['data'];



                var contentTypes = ['application/json', 'application/x-www-form-urlencoded', 'application/xml', 'text/xml'];
                var accepts = ['application/json', 'application/xml', 'text/xml', 'application/javascript', 'text/javascript'];
                var returnType = JeopardyQuestion

                return this.apiClient.callApi('/jeopardyQuestions', 'PATCH', {}, {}, {}, {}, postBody, [], contentTypes, accepts, returnType, callback);
            };
                        
            /**
                * Callback function to receive the result of the jeopardyQuestionPrototypePatchAttributes operation.
                * @callback module: jeopardyapi/api/JeopardyQuestionApi~jeopardyQuestionPrototypePatchAttributesCallback
                * @param {String} error Error message, if any.
                * @param  data The data returned by the service call.
                * @param {String} response The complete HTTP response.
            */
            /**
                * Patch attributes for a model instance and persist it into the data source.
                * @param String id jeopardyQuestion id
                * @param {Object} opts Optional parameters
                * @param module:jeopardyapi/jeopardyapi.model/JeopardyQuestion opts.data An object of model property name/value pairs
                * @param {module:jeopardyapi/api/JeopardyQuestionApi~jeopardyQuestionPrototypePatchAttributesCallback} callback The callback function, accepting three arguments: error, data, response
                * data is of type: {@link <&vendorExtensions.x-jsdoc-type>}
            */

            this.jeopardyQuestionPrototypePatchAttributes = function(id, opts, callback){ 
                var opts = opts || {};
                var postBody = opts['data'];
                // verify the required parameter 'id' is set
                if (id === undefined || id === null) {
                    throw new Error("Missing the required parameter 'id' when calling jeopardyQuestionPrototypePatchAttributes");
                }
            

                var pathParams = {
                    'id': id
                };

                var contentTypes = ['application/json', 'application/x-www-form-urlencoded', 'application/xml', 'text/xml'];
                var accepts = ['application/json', 'application/xml', 'text/xml', 'application/javascript', 'text/javascript'];
                var returnType = JeopardyQuestion

                return this.apiClient.callApi('/jeopardyQuestions/{id}', 'PATCH', pathParams, {}, {}, {}, postBody, [], contentTypes, accepts, returnType, callback);
            };
                        
            /**
                * Callback function to receive the result of the jeopardyQuestionRandom operation.
                * @callback module: jeopardyapi/api/JeopardyQuestionApi~jeopardyQuestionRandomCallback
                * @param {String} error Error message, if any.
                * @param  data The data returned by the service call.
                * @param {String} response The complete HTTP response.
            */
            /**
                * Gets one random question
                * @param {module:jeopardyapi/api/JeopardyQuestionApi~jeopardyQuestionRandomCallback} callback The callback function, accepting three arguments: error, data, response
                * data is of type: {@link <&vendorExtensions.x-jsdoc-type>}
            */

            this.jeopardyQuestionRandom = function(callback){ 
                var postBody = null;



                var contentTypes = ['application/json', 'application/x-www-form-urlencoded', 'application/xml', 'text/xml'];
                var accepts = ['application/json', 'application/xml', 'text/xml', 'application/javascript', 'text/javascript'];
                var returnType = InlineResponse2003

                return this.apiClient.callApi('/jeopardyQuestions/random', 'GET', {}, {}, {}, {}, postBody, [], contentTypes, accepts, returnType, callback);
            };
                        
            /**
                * Callback function to receive the result of the jeopardyQuestionReplaceByIdPostJeopardyQuestionsidReplace operation.
                * @callback module: jeopardyapi/api/JeopardyQuestionApi~jeopardyQuestionReplaceByIdPostJeopardyQuestionsidReplaceCallback
                * @param {String} error Error message, if any.
                * @param  data The data returned by the service call.
                * @param {String} response The complete HTTP response.
            */
            /**
                * Replace attributes for a model instance and persist it into the data source.
                * @param String id Model id
                * @param {Object} opts Optional parameters
                * @param module:jeopardyapi/jeopardyapi.model/JeopardyQuestion opts.data Model instance data
                * @param {module:jeopardyapi/api/JeopardyQuestionApi~jeopardyQuestionReplaceByIdPostJeopardyQuestionsidReplaceCallback} callback The callback function, accepting three arguments: error, data, response
                * data is of type: {@link <&vendorExtensions.x-jsdoc-type>}
            */

            this.jeopardyQuestionReplaceByIdPostJeopardyQuestionsidReplace = function(id, opts, callback){ 
                var opts = opts || {};
                var postBody = opts['data'];
                // verify the required parameter 'id' is set
                if (id === undefined || id === null) {
                    throw new Error("Missing the required parameter 'id' when calling jeopardyQuestionReplaceByIdPostJeopardyQuestionsidReplace");
                }
            

                var pathParams = {
                    'id': id
                };

                var contentTypes = ['application/json', 'application/x-www-form-urlencoded', 'application/xml', 'text/xml'];
                var accepts = ['application/json', 'application/xml', 'text/xml', 'application/javascript', 'text/javascript'];
                var returnType = JeopardyQuestion

                return this.apiClient.callApi('/jeopardyQuestions/{id}/replace', 'POST', pathParams, {}, {}, {}, postBody, [], contentTypes, accepts, returnType, callback);
            };
                        
            /**
                * Callback function to receive the result of the jeopardyQuestionReplaceByIdPutJeopardyQuestionsid operation.
                * @callback module: jeopardyapi/api/JeopardyQuestionApi~jeopardyQuestionReplaceByIdPutJeopardyQuestionsidCallback
                * @param {String} error Error message, if any.
                * @param  data The data returned by the service call.
                * @param {String} response The complete HTTP response.
            */
            /**
                * Replace attributes for a model instance and persist it into the data source.
                * @param String id Model id
                * @param {Object} opts Optional parameters
                * @param module:jeopardyapi/jeopardyapi.model/JeopardyQuestion opts.data Model instance data
                * @param {module:jeopardyapi/api/JeopardyQuestionApi~jeopardyQuestionReplaceByIdPutJeopardyQuestionsidCallback} callback The callback function, accepting three arguments: error, data, response
                * data is of type: {@link <&vendorExtensions.x-jsdoc-type>}
            */

            this.jeopardyQuestionReplaceByIdPutJeopardyQuestionsid = function(id, opts, callback){ 
                var opts = opts || {};
                var postBody = opts['data'];
                // verify the required parameter 'id' is set
                if (id === undefined || id === null) {
                    throw new Error("Missing the required parameter 'id' when calling jeopardyQuestionReplaceByIdPutJeopardyQuestionsid");
                }
            

                var pathParams = {
                    'id': id
                };

                var contentTypes = ['application/json', 'application/x-www-form-urlencoded', 'application/xml', 'text/xml'];
                var accepts = ['application/json', 'application/xml', 'text/xml', 'application/javascript', 'text/javascript'];
                var returnType = JeopardyQuestion

                return this.apiClient.callApi('/jeopardyQuestions/{id}', 'PUT', pathParams, {}, {}, {}, postBody, [], contentTypes, accepts, returnType, callback);
            };
                        
            /**
                * Callback function to receive the result of the jeopardyQuestionReplaceOrCreatePostJeopardyQuestionsReplaceOrCreate operation.
                * @callback module: jeopardyapi/api/JeopardyQuestionApi~jeopardyQuestionReplaceOrCreatePostJeopardyQuestionsReplaceOrCreateCallback
                * @param {String} error Error message, if any.
                * @param  data The data returned by the service call.
                * @param {String} response The complete HTTP response.
            */
            /**
                * Replace an existing model instance or insert a new one into the data source.
                * @param {Object} opts Optional parameters
                * @param module:jeopardyapi/jeopardyapi.model/JeopardyQuestion opts.data Model instance data
                * @param {module:jeopardyapi/api/JeopardyQuestionApi~jeopardyQuestionReplaceOrCreatePostJeopardyQuestionsReplaceOrCreateCallback} callback The callback function, accepting three arguments: error, data, response
                * data is of type: {@link <&vendorExtensions.x-jsdoc-type>}
            */

            this.jeopardyQuestionReplaceOrCreatePostJeopardyQuestionsReplaceOrCreate = function(opts, callback){ 
                var opts = opts || {};
                var postBody = opts['data'];



                var contentTypes = ['application/json', 'application/x-www-form-urlencoded', 'application/xml', 'text/xml'];
                var accepts = ['application/json', 'application/xml', 'text/xml', 'application/javascript', 'text/javascript'];
                var returnType = JeopardyQuestion

                return this.apiClient.callApi('/jeopardyQuestions/replaceOrCreate', 'POST', {}, {}, {}, {}, postBody, [], contentTypes, accepts, returnType, callback);
            };
                        
            /**
                * Callback function to receive the result of the jeopardyQuestionReplaceOrCreatePutJeopardyQuestions operation.
                * @callback module: jeopardyapi/api/JeopardyQuestionApi~jeopardyQuestionReplaceOrCreatePutJeopardyQuestionsCallback
                * @param {String} error Error message, if any.
                * @param  data The data returned by the service call.
                * @param {String} response The complete HTTP response.
            */
            /**
                * Replace an existing model instance or insert a new one into the data source.
                * @param {Object} opts Optional parameters
                * @param module:jeopardyapi/jeopardyapi.model/JeopardyQuestion opts.data Model instance data
                * @param {module:jeopardyapi/api/JeopardyQuestionApi~jeopardyQuestionReplaceOrCreatePutJeopardyQuestionsCallback} callback The callback function, accepting three arguments: error, data, response
                * data is of type: {@link <&vendorExtensions.x-jsdoc-type>}
            */

            this.jeopardyQuestionReplaceOrCreatePutJeopardyQuestions = function(opts, callback){ 
                var opts = opts || {};
                var postBody = opts['data'];



                var contentTypes = ['application/json', 'application/x-www-form-urlencoded', 'application/xml', 'text/xml'];
                var accepts = ['application/json', 'application/xml', 'text/xml', 'application/javascript', 'text/javascript'];
                var returnType = JeopardyQuestion

                return this.apiClient.callApi('/jeopardyQuestions', 'PUT', {}, {}, {}, {}, postBody, [], contentTypes, accepts, returnType, callback);
            };
                        
            /**
                * Callback function to receive the result of the jeopardyQuestionUpdateAll operation.
                * @callback module: jeopardyapi/api/JeopardyQuestionApi~jeopardyQuestionUpdateAllCallback
                * @param {String} error Error message, if any.
                * @param  data The data returned by the service call.
                * @param {String} response The complete HTTP response.
            */
            /**
                * Update instances of the model matched by {{where}} from the data source.
                * @param {Object} opts Optional parameters
                * @param String opts.where Criteria to match model instances
                * @param module:jeopardyapi/jeopardyapi.model/JeopardyQuestion opts.data An object of model property name/value pairs
                * @param {module:jeopardyapi/api/JeopardyQuestionApi~jeopardyQuestionUpdateAllCallback} callback The callback function, accepting three arguments: error, data, response
                * data is of type: {@link <&vendorExtensions.x-jsdoc-type>}
            */

            this.jeopardyQuestionUpdateAll = function(opts, callback){ 
                var opts = opts || {};
                var postBody = opts['data'];


                var queryParams = {
                    'where': opts['where']
                };

                var contentTypes = ['application/json', 'application/x-www-form-urlencoded', 'application/xml', 'text/xml'];
                var accepts = ['application/json', 'application/xml', 'text/xml', 'application/javascript', 'text/javascript'];
                var returnType = InlineResponse2001

                return this.apiClient.callApi('/jeopardyQuestions/update', 'POST', {}, queryParams, {}, {}, postBody, [], contentTypes, accepts, returnType, callback);
            };
                        
            /**
                * Callback function to receive the result of the jeopardyQuestionUpsertWithWhere operation.
                * @callback module: jeopardyapi/api/JeopardyQuestionApi~jeopardyQuestionUpsertWithWhereCallback
                * @param {String} error Error message, if any.
                * @param  data The data returned by the service call.
                * @param {String} response The complete HTTP response.
            */
            /**
                * Update an existing model instance or insert a new one into the data source based on the where criteria.
                * @param {Object} opts Optional parameters
                * @param String opts.where Criteria to match model instances
                * @param module:jeopardyapi/jeopardyapi.model/JeopardyQuestion opts.data An object of model property name/value pairs
                * @param {module:jeopardyapi/api/JeopardyQuestionApi~jeopardyQuestionUpsertWithWhereCallback} callback The callback function, accepting three arguments: error, data, response
                * data is of type: {@link <&vendorExtensions.x-jsdoc-type>}
            */

            this.jeopardyQuestionUpsertWithWhere = function(opts, callback){ 
                var opts = opts || {};
                var postBody = opts['data'];


                var queryParams = {
                    'where': opts['where']
                };

                var contentTypes = ['application/json', 'application/x-www-form-urlencoded', 'application/xml', 'text/xml'];
                var accepts = ['application/json', 'application/xml', 'text/xml', 'application/javascript', 'text/javascript'];
                var returnType = JeopardyQuestion

                return this.apiClient.callApi('/jeopardyQuestions/upsertWithWhere', 'POST', {}, queryParams, {}, {}, postBody, [], contentTypes, accepts, returnType, callback);
            };
            
    };
    return exports;
}));