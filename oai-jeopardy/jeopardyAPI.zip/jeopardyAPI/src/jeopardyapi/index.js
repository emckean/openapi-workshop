(function(factory) {
    if (typeof define === 'function' && define.amd) {
        // AMD. Register as an anonymous module.
        define(['jeopardyapi/ApiClient', 'jeopardyapi/jeopardyapi.model/InlineResponse200', 'jeopardyapi/jeopardyapi.model/InlineResponse2001', 'jeopardyapi/jeopardyapi.model/InlineResponse2002', 'jeopardyapi/jeopardyapi.model/InlineResponse2003', 'jeopardyapi/jeopardyapi.model/InlineResponse2004', 'jeopardyapi/jeopardyapi.model/JeopardyQuestion', 'jeopardyapi/jeopardyapi.model/ObjectID', 'jeopardyapi/api/JeopardyQuestionApi'], factory);
    } else if (typeof module === 'object' && module.exports) {
        // CommonJS-like environments that support module.exports, like Node.
        module.exports = factory(require('./ApiClient'), require('./jeopardyapi.model/InlineResponse200'), require('./jeopardyapi.model/InlineResponse2001'), require('./jeopardyapi.model/InlineResponse2002'), require('./jeopardyapi.model/InlineResponse2003'), require('./jeopardyapi.model/InlineResponse2004'), require('./jeopardyapi.model/JeopardyQuestion'), require('./jeopardyapi.model/ObjectID'), require('./api/JeopardyQuestionApi'));
    }
}(function(ApiClient, InlineResponse200, InlineResponse2001, InlineResponse2002, InlineResponse2003, InlineResponse2004, JeopardyQuestion, ObjectID, JeopardyQuestionApi) {

'use strict';

    /**
        * ERROR_UNKNOWN.<br>
        * The <code>index</code> module provides access to constructors for all the classes which comprise the public API.
        * <p>
        * An AMD (recommended!) or CommonJS application will generally do something equivalent to the following:
        * <pre>
        * var OaiJeopardy = require('jeopardyapi/index'); // See note below*.
        * var service = new OaiJeopardy.xxxApi(); // Allocate the API class we're going to use.
        * var Model = new OaiJeopardy.yyy(); // Construct a model instance.
        * Model.someProperty = 'someValue';
        * ...
        * var response = service.doSomething(Model); // Invoke the service.
        * ...
        * </pre>
        * <em>*NOTE: For a top-level AMD script, use require(['jeopardyapi/index'], function(){...})
        * and put the application logic within the callback function.</em>
        * </p>
        * <p>
        * A non-AMD browser application (discouraged) might do something like this:
        * <pre>
        * var service = new OaiJeopardy.xxxApi(); // Allocate the API class we're going to use.
        * var Model = new OaiJeopardy.Yyy(); // Construct a model instance.
        * Model.someProperty = 'someValue';
        * ...
        * var response = service.doSomething(Model); // Invoke the service.
        * ...
        * </pre>
        * </p>
        * @module jeopardyapi/index
        * @version 1.0.0
        */
     var exports = {
        /**
            * The ApiClient constructor.
            * @property {module:jeopardyapi/ApiClient}
        */
            ApiClient: ApiClient,
        /**
             * The InlineResponse200 model constructor.
             * @property {module:jeopardyapi/jeopardyapi.model/InlineResponse200 }
        */
            InlineResponse200: InlineResponse200,
        /**
             * The InlineResponse2001 model constructor.
             * @property {module:jeopardyapi/jeopardyapi.model/InlineResponse2001 }
        */
            InlineResponse2001: InlineResponse2001,
        /**
             * The InlineResponse2002 model constructor.
             * @property {module:jeopardyapi/jeopardyapi.model/InlineResponse2002 }
        */
            InlineResponse2002: InlineResponse2002,
        /**
             * The InlineResponse2003 model constructor.
             * @property {module:jeopardyapi/jeopardyapi.model/InlineResponse2003 }
        */
            InlineResponse2003: InlineResponse2003,
        /**
             * The InlineResponse2004 model constructor.
             * @property {module:jeopardyapi/jeopardyapi.model/InlineResponse2004 }
        */
            InlineResponse2004: InlineResponse2004,
        /**
             * The JeopardyQuestion model constructor.
             * @property {module:jeopardyapi/jeopardyapi.model/JeopardyQuestion }
        */
            JeopardyQuestion: JeopardyQuestion,
        /**
             * The ObjectID model constructor.
             * @property {module:jeopardyapi/jeopardyapi.model/ObjectID }
        */
            ObjectID: ObjectID,
        /**
             * The JeopardyQuestionApi service constructor.
             * @property {module:jeopardyapi/api/JeopardyQuestionApi }
        */
            JeopardyQuestionApi: JeopardyQuestionApi
    };

    return exports;
 }));