 (function(root, factory) {
        if (typeof define === 'function' && define.amd) {
            // AMD. Register as an anonymous module.
            define(['jeopardyapi/ApiClient', 'jeopardyapi/jeopardyapi.model/ObjectID'], factory);
        } else if (typeof module === 'object' && module.exports) {
            // CommonJS-like environments that support module.exports, like Node.
            module.exports = factory(require('../ApiClient'), require('./ObjectID'));
        } else {
            // Browser globals (root is window)
            if (!root.OaiJeopardy) {
                root.OaiJeopardy = {};
            }
            root.OaiJeopardy.JeopardyQuestion = factory(root.OaiJeopardy.ApiClient, root.OaiJeopardy.ObjectID);
        }
    }(this, function(ApiClient, ObjectID) {

    'use strict';

    
        
    /**
        * The JeopardyQuestion model module.
        * @module jeopardyapi/jeopardyapi.model/JeopardyQuestion
        * @version 1.0.0
    */

    /**
        * Constructs a new <code>JeopardyQuestion</code>.
        * @alias module:jeopardyapi/jeopardyapi.model/JeopardyQuestion
        * @class
        * @param questionString 
        * @param answerString 
    */
    var exports = function(question, answer) {
        var _this = this;
        _this['question'] = question;
        _this['answer'] = answer;
    };

    /**
        * Constructs a <code>JeopardyQuestion</code> from a plain JavaScript object, optionally creating a new instance.
        * Copies all relevant properties from <code>data</code> to <code>obj</code> if supplied or a new instance if not.
        * @param {Object} data The plain JavaScript object bearing properties of interest.
        * @param {module:jeopardyapi/jeopardyapi.model/JeopardyQuestion obj Optional instance to populate.
        * @return {module:jeopardyapi/jeopardyapi.model/JeopardyQuestion The populated <code>JeopardyQuestion</code> instance.
    */
    exports.constructFromObject = function(data, obj) {
        if (data){
            obj = obj || new exports();
    
            if (data.hasOwnProperty('question')) {
                obj['question'] = ApiClient.convertToType(data['question'], 'String');
            }
            if (data.hasOwnProperty('answer')) {
                obj['answer'] = ApiClient.convertToType(data['answer'], 'String');
            }
            if (data.hasOwnProperty('category')) {
                obj['category'] = ApiClient.convertToType(data['category'], 'String');
            }
            if (data.hasOwnProperty('id')) {
                obj['id'] = ObjectID.constructFromObject(data['id']);
            }
        }
        return obj;
    }
    
    
    /**
        * @member String question
    */
    exports.prototype['question'] = undefined;
    /**
        * @member String answer
    */
    exports.prototype['answer'] = undefined;
    /**
        * @member String category
    */
    exports.prototype['category'] = undefined;
    /**
        * @member module:jeopardyapi/jeopardyapi.model/ObjectID id
    */
    exports.prototype['id'] = undefined;

    return exports;

}));
    