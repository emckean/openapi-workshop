 (function(root, factory) {
        if (typeof define === 'function' && define.amd) {
            // AMD. Register as an anonymous module.
            define(['jeopardyapi/ApiClient'], factory);
        } else if (typeof module === 'object' && module.exports) {
            // CommonJS-like environments that support module.exports, like Node.
            module.exports = factory(require('../ApiClient'));
        } else {
            // Browser globals (root is window)
            if (!root.OaiJeopardy) {
                root.OaiJeopardy = {};
            }
            root.OaiJeopardy.InlineResponse2001 = factory(root.OaiJeopardy.ApiClient);
        }
    }(this, function(ApiClient) {

    'use strict';

    
        
    /**
        * The InlineResponse2001 model module.
        * @module jeopardyapi/jeopardyapi.model/InlineResponse2001
        * @version 1.0.0
    */

    /**
        * Constructs a new <code>InlineResponse2001</code>.
        * Information related to the outcome of the operation
        * @alias module:jeopardyapi/jeopardyapi.model/InlineResponse2001
        * @class
    */
    var exports = function() {
        var _this = this;
    };

    /**
        * Constructs a <code>InlineResponse2001</code> from a plain JavaScript object, optionally creating a new instance.
        * Copies all relevant properties from <code>data</code> to <code>obj</code> if supplied or a new instance if not.
        * @param {Object} data The plain JavaScript object bearing properties of interest.
        * @param {module:jeopardyapi/jeopardyapi.model/InlineResponse2001 obj Optional instance to populate.
        * @return {module:jeopardyapi/jeopardyapi.model/InlineResponse2001 The populated <code>InlineResponse2001</code> instance.
    */
    exports.constructFromObject = function(data, obj) {
        if (data){
            obj = obj || new exports();
    
            if (data.hasOwnProperty('count')) {
                obj['count'] = ApiClient.convertToType(data['count'], 'Number');
            }
        }
        return obj;
    }
    
    
    /**
        * The number of instances updated
        * @member Number count
    */
    exports.prototype['count'] = undefined;

    return exports;

}));
    